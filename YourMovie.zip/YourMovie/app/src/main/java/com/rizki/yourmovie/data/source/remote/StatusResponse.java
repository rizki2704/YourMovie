package com.rizki.yourmovie.data.source.remote;

public enum StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}
