package com.rizki.yourmovie.vo;

public enum  Status {
    SUCCESS, ERROR, LOADING
}
